import { Component, OnInit, Input } from '@angular/core';
import { Observable } from 'rxjs';
import { Book } from '../add-book/Book';
import { BookService } from '../add-book/book.service';

@Component({
  selector: 'app-show-all-book',
  templateUrl: './show-all-book.component.html',
  styleUrls: ['./show-all-book.component.css']
})
export class ShowAllBookComponent implements OnInit {
  bookList:Book[];
  

  constructor(private bookservice: BookService ) { }

  ngOnInit() {
    this.bookservice.getBookList().subscribe(data=>this.bookList=data);
  }
  
}
