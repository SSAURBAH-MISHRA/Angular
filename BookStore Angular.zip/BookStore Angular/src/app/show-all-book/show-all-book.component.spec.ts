import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowAllBookComponent } from './show-all-book.component';

describe('ShowAllBookComponent', () => {
  let component: ShowAllBookComponent;
  let fixture: ComponentFixture<ShowAllBookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowAllBookComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowAllBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
