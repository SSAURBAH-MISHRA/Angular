export class Book {
   
    title: string;
    category:string;
    author: string;
    description:string;
    isbn:string;
    thumbnail:string;
    mydate:string;
    price:number;
    updateTime:string
}
