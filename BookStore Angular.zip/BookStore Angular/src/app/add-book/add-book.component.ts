import { Component, OnInit } from '@angular/core';
import { Book } from './Book';
import { BookService } from './book.service';

@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.css']
})
export class AddBookComponent implements OnInit {

  book: Book = new Book();
  submitted = false;

    
  

  constructor(private bookService: BookService) { }

  ngOnInit() {
    
  }
  newBook():void{
    this.submitted = false;
    this.book = new Book();
  }

  save() {
    console.log(this.book.isbn);
    console.log(this.book.thumbnail);
    this.bookService.addBook(this.book)
      .subscribe(data => console.log(data), error => console.log(error));
    this.book = new Book();
  }

  onSubmit() {
    
    
  if(this.book.title.length>128 || this.book.title.length<10){
    alert("Invalid Title (Length should be between 10-128 characters)");
    
  } else{

    if(!this.book.author.match("[A-Za-z]") || this.book.author.length>65)
      {  
        alert("Invalid Author Name (Length should be between 1-65 characters)");
        
      }
    else{
        if(!this.book.category.match("[a-zA-Z]+"))
           {
           alert("Invalid Category");
           } 
           else{
                if(!this.book.isbn.match("[a-zA-Z0-9_+-]*") || (this.book.isbn.length<10 || this.book.isbn.length>15)){
                  alert("Invalid ISBN (Length should be between 10-15 characters)");
                }
                else{
                  if(!this.book.price.toString().match("[0-9]{1,11}(?:\.[0-9]{1,3})?"))
                   {
                    alert("Invalid Price");
            
                  } 
                  else{
              
                   this.submitted=true;
                   this.save();
              
              
                  } 
                }

              }
      }
    }
    

    
  

    
  }

}
