import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Book } from './Book';

@Injectable({
  providedIn: 'root'
})
export class BookService {
  private baseUrl = 'http://localhost:8088/bookstore';
 
  constructor(private http: HttpClient) { }

  addBook(book: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}` + `/addBook`, book);
  }
  getBookList(): Observable<Book[]> {
    return this.http.get<Book[]>(`${this.baseUrl}`+ `/showAllBooks`);
  }
}
