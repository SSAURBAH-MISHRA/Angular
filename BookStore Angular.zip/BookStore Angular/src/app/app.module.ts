import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddBookComponent } from './add-book/add-book.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BookService } from './add-book/book.service';
import { ShowAllBookComponent } from './show-all-book/show-all-book.component';
import { AddCustomerComponent } from './add-customer/add-customer.component';
import { AddcustomerService } from './add-customer/addcustomer.service';

@NgModule({
  declarations: [
    AppComponent,
    AddBookComponent,
    ShowAllBookComponent,
    AddCustomerComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [BookService,AddcustomerService],
  bootstrap: [AddCustomerComponent,AddBookComponent,ShowAllBookComponent]
})
export class AppModule { }
