import { Component, OnInit } from '@angular/core';
import { Customer } from './customer';
import { AddcustomerService } from './addcustomer.service';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit {

  customer: Customer = new Customer();
  submitted = false;

    
  

  constructor(private customerService: AddcustomerService) { }

  ngOnInit() {
    
  }
  newCustomer():void{
    this.submitted = false;
    this.customer = new Customer();
  }

  save() {
    this.customerService.addCustomer(this.customer)
      .subscribe(data => console.log(data), error => console.log(error));
    this.customer = new Customer();
  }

  onSubmit() {
    if(!this.customer.fullName.match("[A-Za-z]") || this.customer.fullName.length<8 || this.customer.fullName.length>30)
    {
      alert("InValid Name (Lentgh should be between 8-30)");

    }
    else{
      if(!this.customer.email.match('[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]'))
      {
        alert("InValid Email Id");
      }
      else{
        if(!this.customer.password.match("(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,16})")){
          alert("Password Should have atleast 1 upper case,lowercase,numeric,and special characters and length should range from 8-16")
        }
        else{
          if(!this.customer.phoneNo.toString().match("[0-9]{10,16}")|| this.customer.phoneNo<0){
            alert("InValid phone number (length should be between 10-15)");
          }
          else{
            if(!this.customer.city.match("[a-zA-Z]{3,32}")){
              alert("InValid city name");
            }
            else{
              if(!this.customer.zipCode.toString().match("[0-9]{3,24}") || this.customer.zipCode<0){
                alert("InValid zip code (length should be between 3-24 )");
              }
              else{
                if(!this.customer.country.match("[a-zA-Z]{3,64}")){
                  alert("InValid Country (length should be between 3-64)");
                }
                else{
                  this.submitted=true;
                  this.save();
                }
              }
            }
          }
        }
      }
    }
    
  }


}
