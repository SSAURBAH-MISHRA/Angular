export class Customer{

    fullName:string ;
    email:string ;
    password :string ;
    phoneNo :number ;
	address :string ;
	city: string ;
    zipCode: number ;
	country :string ;
}