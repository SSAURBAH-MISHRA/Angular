import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from './customer';

@Injectable({
  providedIn: 'root'
})
export class AddcustomerService {
  customer:Customer;
  
  private baseUrl = 'http://localhost:8088/bookstore';
 
  constructor(private http: HttpClient) { }

  addCustomer(customer: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}` + `/addCustomer`, customer);
  }
}
