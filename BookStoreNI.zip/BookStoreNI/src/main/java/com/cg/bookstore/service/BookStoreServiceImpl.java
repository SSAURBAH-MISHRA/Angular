package com.cg.bookstore.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bookstore.entity.Admin;
import com.cg.bookstore.entity.Book;
import com.cg.bookstore.entity.Customer;
import com.cg.bookstore.repo.IBookAdminRepo;
import com.cg.bookstore.repo.IBookCustomerRepo;
import com.cg.bookstore.repo.IBookRepo;

@Service
@Transactional
public class BookStoreServiceImpl implements IBookStoreService {

	@Autowired
	private IBookCustomerRepo customerRepo;
	
	@Autowired
	private IBookRepo bookRepo;
	
	@Autowired
	private IBookAdminRepo adminRepo;
	
	
	

	

	public IBookAdminRepo getAdminRepo() {
		return adminRepo;
	}



	public void setAdminRepo(IBookAdminRepo adminRepo) {
		this.adminRepo = adminRepo;
	}



	public IBookCustomerRepo getCustomerRepo() {
		return customerRepo;
	}



	public void setCustomerRepo(IBookCustomerRepo customerRepo) {
		this.customerRepo = customerRepo;
	}



	public IBookRepo getBookRepo() {
		return bookRepo;
	}



	public void setBookRepo(IBookRepo bookRepo) {
		this.bookRepo = bookRepo;
	}



	@Override
	public int addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		customerRepo.save(customer);
		return customer.getCustomerID();
	}



	@Override
	public int addBook(Book book) {
		System.out.println("###################################################");
		// TODO Auto-generated method stub
		
		bookRepo.save(book);
	
		return book.getBookId();
	}



	@Override
	public int addAdmin(Admin admin) {
		// TODO Auto-generated method stub
		adminRepo.save(admin);
		
		return admin.getAdminId();
	}


	@Override
	public ArrayList<Book> showAllBooks() {
		// TODO Auto-generated method stub
		ArrayList<Book> bookList = (ArrayList<Book>) bookRepo.findAll();
		return bookList;
	}



	@Override
	public ArrayList<Book> showByCategory(String category) {
		// TODO Auto-generated method stub
		ArrayList<Book> bookList = (ArrayList<Book>) bookRepo.findAll();
		ArrayList<Book> books = new ArrayList<>();
		for (Book book : bookList) {
			if(book.getCategory().equalsIgnoreCase(category)) {
				books.add(book);
			}
			
		}
		return books;
	}



	@Override
	public Book findBook(String bookTitle) {
		// TODO Auto-generated method stub
		Book bookFound=new Book();
		ArrayList<Book> bookList = (ArrayList<Book>) bookRepo.findAll();
		for(Book book:bookList) {
			if(book.getTitle().equals(bookTitle)) {
				bookFound=book;
			}
		}
		return bookFound;
	}



	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}
	
	

}
