package com.cg.bookstore.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bookstore.entity.Admin;
import com.cg.bookstore.entity.Book;
import com.cg.bookstore.entity.Customer;
import com.cg.bookstore.service.IBookStoreService;

@RestController
@CrossOrigin("http://localhost:4200")
public class BookStoreController {

	@Autowired
	private IBookStoreService service;

	public IBookStoreService getService() {
		return service;
	}

	public void setService(IBookStoreService service) {
		this.service = service;
	}

	@PostMapping("/addCustomer")
	public int addCustomer(@RequestBody Customer customer) {
		System.out.println("###################################################hello");
		return service.addCustomer(customer);

	}

	@PostMapping("/addBook")
	public int addBook(@RequestBody Book book) {
		System.out.println(book.getISBN() + book.getThumbnail());
		System.out.println("###################################################hello");
		return service.addBook(book);

	}

	@PostMapping("/addAdmin")
	public int addAdmin(@RequestBody Admin admin) {
		return service.addAdmin(admin);

	}
	
	@GetMapping("/showAllBooks")
	public ArrayList<Book> showAllBooks(){
		System.out.println("###########################################################");
		return service.showAllBooks();
	}
	
	@GetMapping("/showByCategory/{category}")
	public ArrayList<Book> showByCategory(@PathVariable String category){
		return service.showByCategory(category);
	}
	@DeleteMapping("/customers/delete")
	public ResponseEntity<String> deleteAllCustomers() {
		System.out.println("Delete All Customers...");

		service.deleteAll();

		return new ResponseEntity<>("All customers have been deleted!", HttpStatus.OK);
	}

}
