package com.cg.bookstore.service;

import java.util.ArrayList;

import com.cg.bookstore.entity.Admin;
import com.cg.bookstore.entity.Book;
import com.cg.bookstore.entity.Customer;

public interface IBookStoreService {

	public int addCustomer(Customer customer);
	
	public int addBook(Book book);
	
	public int addAdmin(Admin admin);
	
	public ArrayList<Book> showAllBooks();
	
	public ArrayList<Book> showByCategory(String category);
	
	public Book findBook(String bookTitle);

	public void deleteAll();

}
