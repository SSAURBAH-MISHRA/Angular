package com.cg.bookstore.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.bookstore.entity.Admin;

public interface IBookAdminRepo extends JpaRepository<Admin, Integer>{

}
