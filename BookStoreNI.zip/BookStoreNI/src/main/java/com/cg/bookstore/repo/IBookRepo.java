package com.cg.bookstore.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.bookstore.entity.Book;

public interface IBookRepo extends JpaRepository<Book, Integer>{

}
