package com.cg.bookstore.entity;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity(name="book")
@SequenceGenerator(name = "book_seq", initialValue = 1000)
public class Book{

	@Id
	@GeneratedValue(generator = "book_seq", strategy = GenerationType.SEQUENCE)
	private int bookId;
	@Column(length=20)
	private String category;
	@Column(length=120)
	private String title;
	@Column(length=64)
	private String author;
	@Column(length=100)
	private String description;
	@Column(length=20)
	private String ISBN;
	@Column(name="thumbnail",length=20)
	private String thumbnail;
	
	@Column(name="price",columnDefinition="number(8,2)")
	private float price;
	@Column(length=20)
	private String mydate;
	@Column(length=20)
	private String updateTime;

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	
	
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getISBN() {
		return ISBN;
	}

	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}

	

	public String getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getMydate() {
		return mydate;
	}

	public void setMydate(String mydate) {
		this.mydate = mydate;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	

	


	

	
	
}
