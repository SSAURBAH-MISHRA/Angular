package com.cg.bookstore.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.bookstore.entity.Customer;

public interface IBookCustomerRepo extends JpaRepository<Customer, Integer> {

}
